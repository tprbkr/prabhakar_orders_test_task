const express = require("express");
const app = express();
const router = express.Router();
const bodyParser = require("body-parser");
const orders = require("./src/routes/controllers/orders");

const port = process.env.PORT || 3000;

// cors implementation
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,OPTIONS");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  next();
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use("/", router);

orders(router);

app.listen(port, () => {
  console.log("server is running at port : ", port);
});
