const orderServies = require("../services/orderService");

module.exports = (router) => {
  // routes for orders crud operations

  // create order
  router.post("/orders/create", (req, res) => {
    orderServies().createOrder(req, res);
  });

  // update order
  router.post("/orders/update/:orderId", (req, res) => {
    orderServies().updateOrder(req, res);
  });

  // list all orders in format yyyy/mm/dd
  router.post("/orders/list", (req, res) => {
    orderServies().orderList(req, res);
  });

  // query for a order with orderId
  router.get("/orders/search/:orderId", (req, res) => {
    orderServies().getOrder(req, res);
  });

  // query for a deleting order
  router.delete("/orders/delete/:orderId", (req, res) => {
    orderServies().deleteOrder(req, res);
  });
};
