const mongoose = require("mongoose");
const order = require("../db/ordersDbSchema");
const { ObjectId } = require("mongoose").Types;
// orders crud operations
module.exports = () => ({
  createOrder: (req, res) => {
    order.create(req.body, (error, orderData) => {
      if (error) {
        res.status(500).send({ Error: "something went wrong at making order" });
      } else {
        res.status(200).send({ "order is successully created": orderData });
      }
    });
  },
  updateOrder: (req, res) => {
    if (req.params.orderId) {
      order.find(
        // { _id: mongoose.Types.ObjectId(req.params.orderId) },
        { order_id: req.params.orderId },
        (err, data) => {
          if (err) {
            res
              .status(201)
              .send({ Error: "something went wrong at updating order" });
          } else if (data.length > 0) {
            order.updateOne(
              { order_id: req.params.orderId },
              { $set: req.body },
              (err, data) => {
                if (err) {
                  res
                    .status(500)
                    .send({ Error: "something went wrong at updating order" });
                } else {
                  res
                    .status(200)
                    .send({ "order is successully updated": data });
                }
              }
            );
          } else {
            res.status(201).send({
              Error: "something went wrong at updating order Id not found",
            });
          }
        }
      );
    } else {
      res
        .status(201)
        .send({ Error: "something went wrong ,orderId is not found" });
    }
  },
  orderList: (req, res) => {
    if (req.body && req.body.date) {
      var dateString = req.body.date;
      if (!/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(req.body.date)) {
        order.find({ order_date: dateString }, (err, data) => {
          if (err) {
            res
              .status(500)
              .send({ Error: "something went wrong at listing orders" });
          } else if (data && data.length > 0) {
            res.status(200).send({ "orders successully fetched": data });
          } else {
            res.status(201).send({
              Error: "something went wrong!",
            });
          }
        });
      } else {
        res.status(201).send({
          Error:
            "something went wrong ,date feild is not in valid format , please enter yyyy/mm/dd",
        });
      }
    } else {
      res
        .status(201)
        .send({ Error: "something went wrong ,date feild is not found" });
    }
  },
  getOrder: (req, res) => {
    if (req.params.orderId) {
      order.find({ order_id: req.params.orderId }, (err, data) => {
        if (err) {
          res
            .status(500)
            .send({ Error: "something went wrong at getting order details" });
        } else if (data && data.length > 0) {
          res.status(200).send({ "order details successully fetched": data });
        } else {
          res.status(201).send({ Error: "no orders found for this id" });
        }
      });
    } else {
      res
        .status(201)
        .send({ Error: "something went wrong ,orderId is not found" });
    }
  },
  deleteOrder: (req, res) => {
    if (req.params.orderId) {
      order.deleteOne({ order_id: req.params.orderId }, (err, data) => {
        if (err) {
          res
            .status(500)
            .send({ Error: "something went wrong at deleting order details" });
        } else {
          res.status(200).send({ "order is successully deleted": data });
        }
      });
    } else {
      res
        .status(201)
        .send({ Error: "something went wrong ,orderId is not found" });
    }
  },
});
