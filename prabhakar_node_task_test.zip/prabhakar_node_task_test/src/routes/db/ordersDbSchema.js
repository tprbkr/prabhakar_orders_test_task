const mongoose = require("mongoose");
const assert = require("assert");
mongoose.Promise = global.Promise;

const db = mongoose.connect("mongodb://localhost:27017/prabhakar_test_orders", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// const { Schema } = mongooseModel;

const orderSchema = new mongoose.Schema(
  {
    order_id: {
      type: String,
    },
    item_name: {
      type: String,
    },
    cost: {
      type: String,
    },
    order_date: {
      type: String,
    },
    delivery_date: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

const order = mongoose.model("orders", orderSchema);

module.exports = order;
